/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package semana.pkg2;

import javax.swing.JOptionPane;

/**
 *
 * @author gcastro
 */
public class ExtraClase1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        Trabajo Extra Clase #1
        
        - Desarrolle un ejercicio que le solicite al usuario lo siguiente:
            1) A;os de antiguedad. 
            2) La cantidad de horas laboradas por semana. 
            3) Precio que se le paga por hora. 
        Con estos datos se debe calcular el salario bruto. 
        
        - Si el usuario tiene mas de 12 a;os de trabajar para la empresa:
            1) Se le dara un bono del 5.5% de su salario bruto. 
            2) Si este nuevo salario bruto es superior a $2500, se le rebaja 2.7%.
            3) Si el salario supera los $3500, se le rebaja 3.8%. 
        
        - Muestre al usuario el salario neto final. 
        
         */

        //Variables//
        String anhos = "";
        int antiguedad = 0;
        String tiempo = "";
        int hrsSemanales = 0;
        String costo = "";
        double salarioHrs = 0;

        //Solicitud de informacion//
        JOptionPane.showMessageDialog(null, "Bienvenid@ al servicio de RRHH!"); //Msj de bienvenida. 

        anhos = JOptionPane.showInputDialog("Ingrese su antiguedad laboral: "); //Solicitud de antiguedad.
        antiguedad = Integer.parseInt(anhos);

        tiempo = JOptionPane.showInputDialog("Cuantas horas labora por semana?: ");// Solicitud de horas laboradas. 
        hrsSemanales = Integer.parseInt(tiempo);

        costo = JOptionPane.showInputDialog("Cual es su salario por hora?: "); //Solicitud del salario por hora.
        salarioHrs = Double.parseDouble(costo);

        //Calculos//
        double salarioBruto = (salarioHrs * hrsSemanales) * 4;
        /*Se calcula el Salario Bruto, multiplicando las horas laboradas, por el salario en horas 
                                                          y el total se multiplica por 4.*/

        //Desarrollo del programa//
        if (antiguedad < 12) {
            JOptionPane.showMessageDialog(null, "Lo sentimos, no aplica para el aumento."); //Se valida si la antiguedad es mayor a 12, de lo contrario muestra error. 
        } 
        else if (antiguedad > 12) {
            salarioBruto = ((salarioBruto * 0.055) + salarioBruto); //Si la antiguedad es > 12, se le agrega 5.5% al salario bruto. 

            if (salarioBruto > 3500) { //valida si el nuevo salario es > 3500 y se le aplica un rebajo del 3.8%.
                double deducciones = (salarioBruto * 0.038);
                double salarioNeto = (salarioBruto - deducciones);
                JOptionPane.showMessageDialog(null, "Felicidades, por cumplir " + antiguedad + " anhos de laborar en la empresa,se vera beneficiado de un aumento del 5.5%." + "\n"
                        + "\n"
                        + "Nuevo Salario: $" + salarioBruto
                        + "\n" + "Deducciones: $" + deducciones
                        + "\n" + "Salario Neto: $" + salarioNeto);
            } 
            else if (salarioBruto < 2500) { //valida si el nuevo salario es < a 2500 y muestra error.
                JOptionPane.showMessageDialog(null, "Lo sentimos, no aplica para el aumento.");
            } 
            else if (salarioBruto > 2500) { //valida si el nuevo salario es > 2500 y se le aplica un rebajo del 2.7%.
                double deducciones = (salarioBruto * 0.027);
                double salarioNeto = (salarioBruto - deducciones);
                JOptionPane.showMessageDialog(null, "Felicidades, por cumplir " + antiguedad + " anhos de laborar en la empresa,se vera beneficiado de un aumento del 5.5%." + "\n"
                        + "\n"
                        + "Nuevo Salario: $" + salarioBruto
                        + "\n" + "Deducciones: $" + deducciones
                        + "\n" + "Salario Neto: $" + salarioNeto);
            }

        }

    }

}


