/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package semana.pkg2;

import javax.swing.JOptionPane;

/**
 *
 * @author gcastro
 */
public class Semana2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //Practicas de Semana 1:
        //Ejercicio #1:
        /*
        Escriba un programa que lea el nombre del trabajador y su salario semanal, con esta información
        calcule su salario mensual sin deducciones (salario bruto), el monto de las deducciones (que
        corresponden a un 9.34%) y el salario después de aplicadas las deducciones (salario neto), finalmente
        debe mostrar los datos al usuario de la siguiente manera.
            Estimado <<nombre>>, el salario de este mes se desglosa de la siguiente manera.
            Salario bruto: #####.##
            Deducciones: #####.##
            Salario Neto: #####.##
         */
 /*
        //creacion de variables//
        String nombreTrabajador = "";
        double salarioSemanal = 0;
        double salarioMensual = 0;
        double salarioBruto = 0;
        double deducciones = 0.0934;
        double salarioNeto = 0;
        String variableTemporal = "";
        
        //Solicitud datos//
        nombreTrabajador = JOptionPane.showInputDialog("Digite su nombre completo: ");
        variableTemporal = JOptionPane.showInputDialog("Ingrese su salario semanal: ");
        
        //Cambio de String a numero:
        salarioSemanal = Double.parseDouble(variableTemporal);
        
        
        //Calculos//
        salarioMensual = salarioSemanal*4;
        salarioBruto = salarioMensual;
        deducciones = salarioMensual*0.0934;
        salarioNeto = salarioBruto - deducciones;
        
        //Respuesta final//
        JOptionPane.showMessageDialog(null,"Estimado " + nombreTrabajador + ". " + "El salario de este mes se desgloza de la siguiente manera: " + "\n"
                                            + "Salario Bruto: $" + salarioBruto + "\n"
                                            + "Deducciones: $" + deducciones + "\n"
                                            + "Salario Neto: $" + salarioNeto + "\n");
         */
        //-------------------------------------------------------------------------------------------------------------------------------------------------------//
        /* 
        
        //Ejercicio #2:
        
        1. Escriba un programa que calcule la suma y el promedio de cuatro números de tipo int. Muestre los
        resultados. Usted le asigna los valores a las variables.
        
        2. Modifique el programa que realizó en el punto anterior, de modo que lea los valores que se van a
        sumar.
         */
 /*
        //Respuestas//
        
        //Variables//
        
        int variableA = 100;
        int variableB = 200;
        int variableC = 300;
        int variableD = 400;
        
        //Calculos//
        
        double total = variableA + variableB + variableC + variableD;
        double promedio = total/4;
        
        //Respuesta final 1.0//
        JOptionPane.showMessageDialog(null, "Parte 1: ");
        JOptionPane.showMessageDialog(null,"Los valores que se van a sumar, son los siguientes: " + "\n"
                                        + "\n"
                                        + "Valor #1: " + variableA + "\n"
                                        + "Valor #2: " + variableB + "\n"
                                        + "Valor #3: " + variableC + "\n"
                                        + "Valor #4: " + variableD + "\n"
                                        + "\n"
                                        + "La suma total, equivale a: " + total + "\n"
                                        + "El promedio, equivale a: " + promedio + "\n");
        
        //Variables 1.2//
        
        String temporal1 = "";
        double variable1 = 0;
        String temporal2 = "";
        double variable2 = 0;
        String temporal3 = "";
        double variable3 = 0;
        String temporal4 = "";
        double variable4 = 0;
        
        //Solicitud de datos//
        
        //NOTA: despues de varios intentos, me di cuenta que el Double.parseDouble solo aplica con la ultima linea, 
        //es por eso que los puse despues de cada solicitud de JOptionPane.showImputDialog.//
        
        JOptionPane.showMessageDialog(null,"Parte 2: ");

        temporal1 = JOptionPane.showInputDialog("Ingrese el valor de A: ");
        variable1 = Double.parseDouble(temporal1);
        temporal2 = JOptionPane.showInputDialog("Ingrese el valor de B: ");
        variable2 = Double.parseDouble(temporal2);
        temporal3 = JOptionPane.showInputDialog("Ingrese el valor de C: ");
        variable3 = Double.parseDouble(temporal3);
        temporal4 = JOptionPane.showInputDialog("Ingrese el valor de D: ");
        variable4 = Double.parseDouble(temporal4);
        
        //Calculos//
        
        double total1 = variable1 + variable2 + variable3 + variable4;
        double promedio1 = total1/4;
        
        //Respuesta final 1.2//
        
        JOptionPane.showMessageDialog(null,"Los valores que se van a sumar, son los siguientes: " + "\n"
                                        + "\n"
                                        + "Valor #1: " + variable1 + "\n"
                                        + "Valor #2: " + variable2 + "\n"
                                        + "Valor #3: " + variable3 + "\n"
                                        + "Valor #4: " + variable4 + "\n"
                                        + "\n"
                                        + "La suma total, equivale a: " + total1 + "\n"
                                        + "El promedio, equivale a: " + promedio1 + "\n");
        
         */
        //------------------------------------------------------------------------------------------------------------------------------------------------//
        //Ejercicios de Practica Semana #2//
        //Ejercicio #1:
        /*
    Escriba un nuevo programa en JAVAque le solicite al
    usuario su edad y le indique si puede o no puede votar.
    • Considere que en nuestro país, solo las personas con
    18 años o más pueden votar.
         */
 /*
        //Respuestas//
        
        //Variables//
        
        int edad = 0;
        
        //Solicitud de informacion//
        
        edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su edad: "));
        
        //Desarrollo del programa//
         if (edad >= 18){
        JOptionPane.showMessageDialog(null, "Bienvenido, su edad es " + edad + "; si puede votar.");
        }else{
             JOptionPane.showMessageDialog(null,"Lo sentimos, las votaciones son solo para 18+. Dado que su edad actual es " + edad + ", aun no puede votar.");
         }
       
        //------------------------------------------------------------------------------------------------------------------------------------------------//

         */
        //Ejercicio #2//
        /*
        Escriba un nuevo programa en JAVA que le solicite al usuario la nota final del curso anterior y le indique si aprobó o no.
        • Considere que para aprobar debe obtener una nota igual o superior a 70.
         */
 /*
        //Respuestas//
        //Variables//
        int notaFinal = 0;

        //Solicitud de Informacion//
        notaFinal = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la nota final del curso: "));

        //Desarrollo del App//
        if (notaFinal >= 70) {
            JOptionPane.showMessageDialog(null, "Felicitaciones, aprobo el curso! :D ");
        } else {
            JOptionPane.showMessageDialog(null, "Lo sentimos, el curso fue reprobado. :1 ");
        }
         */
        //------------------------------------------------------------------------------------------------------------------------------------------------//
        //Ejercicio #3//
        /* 
        Escriba un programa que le solicite al usuario el numero de dia y le indique el nombre del dia. 
        Por ejemplo: 1=Domingo, 2=Lunes, 3=Martes, etc...
         */
 /*
        //Respuestas//
        //Variables//
        int numeroDia = 0;
        
        //Solicitud de datos//
        numeroDia = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un numero para saber el dia correspondiente: "));
        
        //Desarrollo del App//
        
        switch (numeroDia){
            case 1:
                JOptionPane.showMessageDialog(null, "El 1 equivale a Lunes.");
                break;
            case 2:
                JOptionPane.showMessageDialog(null, "El 2 equivale a Martes.");
                break;
            case 3:
                JOptionPane.showMessageDialog(null, "El 3 equivale a Miercoles.");
                break;
            case 4:
                JOptionPane.showMessageDialog(null, "El 4 equivale a Jueves.");
                break;
            case 5:
                JOptionPane.showMessageDialog(null, "El 5 equivale a Viernes.");
                break;
            case 6:
                JOptionPane.showMessageDialog(null, "El 6 equivale a Sabado.");
                break;
            case 7:
                JOptionPane.showMessageDialog(null, "El 7 equivale a Domingo.");
                break;
            default: 
                JOptionPane.showMessageDialog(null,"Numero invalido, por favor digite un numero del 1 al 7.");
        }
        if (numeroDia ==6 || numeroDia == 7){
         JOptionPane.showMessageDialog(null, "Es dia libre.");
            } else if( numeroDia == 1 || numeroDia == 2 || numeroDia == 3 || numeroDia == 4 || numeroDia ==5) {
                JOptionPane.showMessageDialog(null, "Es dia laboral.");
            } else {
                JOptionPane.showMessageDialog(null,"Numero invalido, por favor digite un numero del 1 al 7.");
            }
         */
 /*
        //------------------------------------------------------------------------------------------------------------------------------------------------//
        
        Ejercicio 3
        Escriba un programa que le solicite al usuario 4 números y le muestre cuál es el
        mayor.
         */
 /*
        //Respuestas//
        //Variables//
        String Juan = "";
        int estaturaA = 0;
        String Pedro = "";
        int estaturaB = 0;
        String Isaac = "";
        int estaturaC = 0;
        String Pablo = "";
        int estaturaD = 0;

        //Solicitud de informacion//
        Juan = JOptionPane.showInputDialog("Ingrese la estatura de Juan: ");
        estaturaA = Integer.parseInt(Juan);
        Pedro = JOptionPane.showInputDialog("Ingrese la estatura de Pedro: ");
        estaturaB = Integer.parseInt(Pedro);
        Isaac = JOptionPane.showInputDialog("Ingrese la estatura de Isaac: ");
        estaturaC = Integer.parseInt(Isaac);
        Pablo = JOptionPane.showInputDialog("Ingrese la estatura de Pablo: ");
        estaturaD = Integer.parseInt(Pablo);

        //Calculos//
        double mayor = estaturaA;

        if (estaturaB > mayor) {
            mayor = estaturaB;
        }

        if (estaturaC > mayor) {
            mayor = estaturaC;
        }

        if (estaturaD > mayor) {
            mayor = estaturaD;
        }

        //Respuesta//
        JOptionPane.showMessageDialog(null, "Segun las estaturas brindadas: " + "\n"
                + "\n"
                + "Juan: " + estaturaA
                + "\n" + "Pedro: " + estaturaB
                + "\n" + "Isaac: " + estaturaC
                + "\n" + "Pablo: " + estaturaD
                + "\n"
                + "\n" + "La estatura mayor, es: " + mayor);
        
         */
        //NOTA: Se agradece cualquier feedback...//
//------------------------------------------------------------------------------------------------------------------------------------------------//
    }
}
