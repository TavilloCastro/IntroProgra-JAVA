/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package semana.pkg1;

import javax.swing.JOptionPane;

/**
 *
 * @author gcastro
 */
public class Semana1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Esto es un comentario!
        //Tipos de variables:
        String nombre;
        int edad;
        float salario;
        double temperatura;
        char inicial;

        String welcomemsg = "Hola, bienvenido.";
        
        nombre = JOptionPane.showInputDialog("Digite su nombre:");
    }
    
}
